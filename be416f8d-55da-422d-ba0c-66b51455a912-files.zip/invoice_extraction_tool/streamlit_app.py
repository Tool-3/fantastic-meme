# This file is just a symbolic link to app.py for Streamlit Cloud compatibility
from app import main

if __name__ == "__main__":
    main()